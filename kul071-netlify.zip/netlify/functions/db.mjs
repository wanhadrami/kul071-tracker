import {getStore} from '@netlify/blobs';import {role,deny} from './_auth.mjs';
const ADMIN_ONLY=['base/','p6sum/'];
export default async req=>{const r=role(req);if(!r)return deny();const st=getStore({name:'kul071',consistency:'strong'});const u=new URL(req.url);
 if(req.method==='GET'){const {blobs}=await st.list();const out={};await Promise.all(blobs.map(async b=>{out[b.key]=await st.get(b.key,{type:'json'})}));return Response.json(out)}
 const path=req.method==='DELETE'?u.searchParams.get('path'):(await req.clone().json()).path;
 if(!path||!/^[A-Za-z0-9_\-.~:@+\/]+$/.test(path))return new Response('bad path',{status:400});
 if(ADMIN_ONLY.some(p=>path.startsWith(p))&&r!=='admin')return new Response('admin only',{status:403});
 if(req.method==='PUT'){const {data}=await req.json();await st.setJSON(path,data);return Response.json({ok:true})}
 if(req.method==='DELETE'){await st.delete(path);return Response.json({ok:true})}
 return new Response('method',{status:405})};
export const config={path:'/api/db'};
